package com.example.laboratorio01.listview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {


    TextView estado;
    TextView estadoDes;

    String[] descricoes = {"é quente", "tem acarajé", "tem Whindersson"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        estado = findViewById(R.id.id_estados);
        estadoDes = findViewById(R.id.id_descricao);

        Intent intent = getIntent();
        String texto = intent.getStringExtra("estados");

        if(texto != null){
            estado.setText(texto.toString());

            if(texto.equals("Ceará")){
             estadoDes.setText(descricoes[0]);
            }else if (texto.equals("Bahia")){
                estadoDes.setText(descricoes[1]);
            } else if (texto.equals("Piauí")){
            estadoDes.setText(descricoes[2]);
        }
        }

    }
}
