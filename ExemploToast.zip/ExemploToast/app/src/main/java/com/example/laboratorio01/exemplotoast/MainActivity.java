package com.example.laboratorio01.exemplotoast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText n1;
    EditText n2;
    EditText n3;
    Button btAcao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btAcao = findViewById(R.id.btExemplo);
        n1 = findViewById(R.id.etUm);
        n2 = findViewById(R.id.etDois);
        n3 = findViewById(R.id.etTres);


        int a = Integer.parseInt(n1.getText().toString());
        int b = Integer.parseInt(n1.getText().toString());
        int c = Integer.parseInt(n1.getText().toString());


        if (a == b && b == c ){
            btAcao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "Equilatero", Toast.LENGTH_LONG).show();
                }
            });
        } else if (a == b || b == c || c == a){
            btAcao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "Isosceles", Toast.LENGTH_LONG).show();
                }
            });
        } else if (a != b && b != c && a != c){
            btAcao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "Escaleno", Toast.LENGTH_LONG).show();
                }
            });
        } else {
            btAcao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),"Não é triangulo", Toast.LENGTH_LONG).show();
                }
            });

        }

    }
}
