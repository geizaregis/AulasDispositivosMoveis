package com.example.laboratorio01.exerciciointernalstorage;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;


public class MainActivity extends AppCompatActivity {
    EditText nome;
    EditText email;
    EditText senha;
    Button salvar;
    final String ARQUIVO_USUARIO = "dadosUsuario.txt";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome=findViewById(R.id.nome);
        email=findViewById(R.id.email);
        senha=findViewById(R.id.senha);
        salvar=findViewById(R.id.salvar);

        if(carregarDados()!=null){
            nome.setText(carregarDados()[0]);
            email.setText(carregarDados()[1]);
            senha.setText(carregarDados()[2]);
        }

        salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nomedigitado = nome.getText().toString();
                String emaildigitado = email.getText().toString();
                String senhadigitado = senha.getText().toString();

                String textoCompleto =nomedigitado+";"+emaildigitado+";"+senhadigitado;

                if(!textoCompleto.isEmpty()){
                    salvarArquivo(textoCompleto);
                    Toast.makeText(MainActivity.this,"Usuário salvo com sucesso", Toast.LENGTH_SHORT).show();
                }


            }
        });


    }

    public void salvarArquivo(String dados){
        try{
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(openFileOutput(ARQUIVO_USUARIO, Context.MODE_PRIVATE));
            outputStreamWriter.write(dados);
            outputStreamWriter.close();
        }catch (IOException e){
            Log.v("MainActiviy", e.getMessage());
        }
    }

    public String[] carregarDados(String[] dados){
        String[]  dadosCarregados = null;
        try{
            InputStream arquivoCarregado = openFileInput(ARQUIVO_USUARIO);
            if(arquivoCarregado!=null){
                InputStreamReader inputStreamReader = new InputStreamReader(arquivoCarregado);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                if(bufferedReader.readLine()!=null){
                    dadosCarregados = bufferedReader.readLine().split(";");
                }
            }
        }catch (IOException e){
            Log.v("MainActiviy", e.getMessage());
        }
        return dadosCarregados;
    }

}
