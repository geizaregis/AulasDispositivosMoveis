package com.example.laboratorio01.revisaoum;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText camposalario;
    Button botaocalcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        camposalario = findViewById(R.id.id_salario);
        botaocalcular = findViewById(R.id.bt_calcular);
        final double salarioBruto = Double.parseDouble(camposalario.getText().toString());
        botaocalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,DescontoINSS.class);
                double salarioLiquido = 0;

                if(salarioBruto<=1751.81){
                    salarioLiquido = calcularSalarioLiq(salarioBruto, 8);
                }else if (salarioBruto<=2919.72){
                    salarioLiquido = calcularSalarioLiq(salarioBruto, 9);
                }else if (salarioBruto<=5839.45) {
                    salarioLiquido = calcularSalarioLiq(salarioBruto, 11);
                }

                intent.putExtra("salario", salarioLiquido);
                startActivity(intent);
                }
        });
    }

    public double calcularSalarioLiq(double salario, double porcentagem){
        double desconto = (salario*porcentagem)/100;
        return salario - desconto;
    }
}
