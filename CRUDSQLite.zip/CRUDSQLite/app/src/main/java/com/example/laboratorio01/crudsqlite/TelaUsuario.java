package com.example.laboratorio01.crudsqlite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.laboratorio01.crudsqlite.usuario.Usuario;
import com.example.laboratorio01.crudsqlite.usuario.UsuarioDAO;

public class TelaUsuario extends AppCompatActivity {
    Usuario usuario;
    UsuarioDAO usuarioDAO ;
    Usuario usuarioCarregado;
    EditText cadNome;
    EditText cadSenha;
    EditText cadUsuario;

    Button btSalvar;
    Button btExcluir;
    Button btPesquisar;
    Button btSincronizar;
    Button btVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_usuario);

        cadNome =findViewById(R.id.cadNome);
        cadSenha =findViewById(R.id.cadSenha);
        cadUsuario =findViewById(R.id.cadUsuario);

        btExcluir =findViewById(R.id.btExcluir);
        btPesquisar =findViewById(R.id.btPesquisar);
        btSalvar =findViewById(R.id.btSalvar);
        btSincronizar =findViewById(R.id.btSincronizar);
        btVoltar =findViewById(R.id.btVoltar);

        usuario = new Usuario();
        usuarioCarregado = new Usuario();

        usuarioDAO = new UsuarioDAO(openOrCreateDatabase(usuarioDAO.NOME_BANCO, MODE_PRIVATE, null));

        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(usuarioCarregado !=null){
                    if(usuarioCarregado.getId() != 0){
                        usuarioCarregado.setNome(cadNome.getText().toString());
                        usuarioCarregado.setSenha(cadSenha.getText().toString());
                        usuarioCarregado.setLogin(cadUsuario.getText().toString());
                        usuarioDAO.salvarUsuario(usuarioCarregado);
                    }else{
                        usuario.setNome(cadNome.getText().toString());
                        usuario.setSenha(cadSenha.getText().toString());
                        usuario.setLogin(cadUsuario.getText().toString());
                        usuarioDAO.salvarUsuario(usuario);

                    }
                    Toast.makeText(getApplicationContext(),"Dados salvos!",Toast.LENGTH_SHORT).show();
                    limparCampos();
                }

            }
        });

        btPesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TelaUsuario.this,TelaPesquisarUsuario.class));
               
            }
        });

        btExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(usuarioCarregado.getId()!=0){
                    usuarioDAO.deletarUsuario(usuarioCarregado);
                    limparCampos();
                }

            }
        });

        carregarUsuarios();
    }

    public void limparCampos(){
        cadNome.setText("");
        cadSenha.setText("");
        cadUsuario.setText("");

        usuario = new Usuario();
        usuarioCarregado = new Usuario();
    }

    public void carregarUsuarios(){
        Intent i = getIntent();
        usuarioCarregado =(Usuario) i.getSerializableExtra("usuario");
        if(usuarioCarregado!=null){
            cadNome.setText(usuarioCarregado.getNome());
            cadUsuario.setText(usuarioCarregado.getLogin());
            cadSenha.setText(usuarioCarregado.getSenha());
            btExcluir.setEnabled(true);
        }else{
            btExcluir.setEnabled(false);
        }

    }


}
