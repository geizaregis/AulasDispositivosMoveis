package com.example.laboratorio01.crudsqlite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.laboratorio01.crudsqlite.usuario.Usuario;
import com.example.laboratorio01.crudsqlite.usuario.UsuarioDAO;

import java.util.ArrayList;

public class TelaPesquisarUsuario extends AppCompatActivity {
UsuarioDAO usuarioDAO;
    ArrayList<Usuario> listaUsuarios;
    ArrayAdapter usuaariosAdaptador;

    Button btPesquisar;
    ListView listUsuarios;
    EditText usuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pesquisar_usuario);


        btPesquisar = findViewById(R.id.btFiltrarUsuario);
        listUsuarios = findViewById(R.id.listViewUsuarios);
        usuario = findViewById(R.id.campoPesquisarUsuario);

        usuarioDAO = new UsuarioDAO(openOrCreateDatabase(usuarioDAO.NOME_BANCO, MODE_PRIVATE, null));

        listaUsuarios =usuarioDAO.listarUsuario();
        listarUsuarios(listaUsuarios);

        btPesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!usuario.getText().toString().isEmpty()){
                    listaUsuarios = usuarioDAO.listarUsuario(usuario.getText().toString());
                    listarUsuarios(listaUsuarios);

                }
            }
        });

        listUsuarios.setLongClickable(true);
        listUsuarios.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(TelaPesquisarUsuario.this,TelaUsuario.class);
                intent.putExtra("usuario",listaUsuarios.get(position));
                startActivity(intent);
                return true;
            }
        });

    }
    public void listarUsuarios(ArrayList lista){
        usuaariosAdaptador=new ArrayAdapter<Usuario>(this,android.R.layout.simple_expandable_list_item_2, android.R.id.text2, lista);
        listUsuarios.setAdapter(usuaariosAdaptador);

    }
}
