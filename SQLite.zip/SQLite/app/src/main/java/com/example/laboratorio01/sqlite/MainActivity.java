package com.example.laboratorio01.sqlite;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try{
            SQLiteDatabase banco = openOrCreateDatabase("Sistema", MODE_PRIVATE,null);
            //criar tabela
            banco.execSQL("CREATE TABLE IF NOT EXISTS usuario(id INTEGER PRIMARY KEY AUTOINCREMENT,usuario VARCHAR, senha INTEGER(8))");
            //inserção de dados
            //banco.execSQL("INSERT INTO usuario (usuario, senha) VALUES ('Geiza',12335252)");
            //banco.execSQL("INSERT INTO usuario (usuario, senha) VALUES ('jabf',12352)");
            //banco.execSQL("INSERT INTO usuario (usuario, senha) VALUES ('hbvabdv',123252)");

            //alterar dados
            banco.execSQL("UPDATE usuario SET usuario = 'Bardo' WHERE id = 1");

            //excluir dados
            banco.execSQL("DELETE FROM  usuario WHERE id='2'");



            //Retornar e listar dados do BD
            Cursor cursor = banco.rawQuery("SELECT * FROM usuario WHERE usuario LIKE '%ard%'",null);
            int indiceId = cursor.getColumnIndex("id");
            int indiceUsuario = cursor.getColumnIndex("usuario");
            int indiceSenha = cursor.getColumnIndex("senha");

            //voltar pra o primeiro item da lista
            cursor.moveToFirst();
            while(cursor!=null){
                Log.i("DADOS USUARIO - id", cursor.getString(indiceId));
                Log.i("DADOS USUARIO - usuario", cursor.getString(indiceUsuario));
                Log.i("DADOS USUARIO - senha", cursor.getString(indiceSenha));
                cursor.moveToNext();//avançar para o proximo resultado
            }
        }catch(Exception e){
            e.printStackTrace();
        }




    }
}
