package com.example.laboratorio01.listview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ListView lista;

    private String[] listaEstados = {"Ceará", "Alagoas", "Pernambuco", "Bahia", "Rio Grande do Norte","Piauí",
            "Ceará", "Alagoas", "Pernambuco", "Bahia", "Rio Grande do Norte","Piauí"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lista =findViewById(R.id.lista);

        ArrayAdapter<String> adaptador = new ArrayAdapter<>(
        getApplicationContext(),android.R.layout.simple_list_item_1,android.R.id.text1,listaEstados);

        lista.setAdapter(adaptador);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String textocapturado = lista.getItemAtPosition(position).toString();

                Toast.makeText(getApplicationContext(),textocapturado,Toast.LENGTH_SHORT).show();

            }
        });






    }
}
