package com.example.laboratorio01.interacaoactivities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    TextView texto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        texto = findViewById(R.id.texto)
        String textoCapturado;
        Bundle bundle = getIntent().getExtras();
        if (bundle != null){
           textoCapturado = bundle.getString("nome");
           texto.setText(textoCapturado);
        }



    }
}
